import React from 'react';
import './index.css';

const App = () => {
  const handleSubmit = (event) => {
    event.preventDefault();
    alert('Form submitted!');
  };

  const allowDrop = (event) => {
    event.preventDefault();
  };

  const drag = (event) => {
    event.dataTransfer.setData('text', event.target.id);
  };

  const drop = (event) => {
    event.preventDefault();
    const data = event.dataTransfer.getData('text');
    const draggedElement = document.getElementById(data);
    event.target.appendChild(draggedElement);
  };

  return (
    <div>
      {/* Responsive Navigation Bar */}
      <div className="navbar">
        <span className="title">Insurance Company</span>
        <nav>
          <a href="#">Home</a>
          <a href="#">About</a>
          <a href="#">Services</a>
          <a href="#">Contact</a>
        </nav>
      </div>

      {/* Form with Input Validation */}
      <div className="container">
        <span className="title">Insurance Quote Request</span>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="fullName">Full Name:</label>
            <input type="text" id="fullName" name="fullName" required />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input type="email" id="email" name="email" required />
          </div>

          <div className="form-group">
            <label htmlFor="insuranceType">Insurance Type:</label>
            <select id="insuranceType" name="insuranceType" required>
              <option value="auto">Auto Insurance</option>
              <option value="home">Home Insurance</option>
              <option value="life">Life Insurance</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="message">Additional Information:</label>
            <textarea id="message" name="message" rows="4"></textarea>
          </div>

          <button type="submit">Get a Quote</button>
        </form>
      </div>

      {/* Other sections (Video, Audio, Canvas, External Webpage, Drag & Drop, Features) */}
      {/* ... (Remaining HTML code) */}

      {/* Features Section with Articles */}
      <section>
        <div class="container">
          <span class="title">Featured Video</span>
          <video controls>
            <source src="your-video.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>

        <div class="container">
          <span class="title">Featured Audio</span>
          <audio controls>
            <source src="your-audio.mp3" type="audio/mp3" />
            Your browser does not support the audio tag.
          </audio>
        </div>

        <div class="container">
          <span class="title">Canvas Drawing</span>
          <canvas id="myCanvas" width="200" height="100"></canvas>
          <script>
            const canvas = document.getElementById('myCanvas'); const ctx =
            canvas.getContext('2d'); ctx.fillStyle = 'blue'; ctx.fillRect(10,
            10, 50, 50);
          </script>
        </div>

        <div class="container">
          <span class="title">External Webpage</span>
          <iframe src="contact.html" title="External Webpage"></iframe>
        </div>

        <div class="container drag-container">
          <span class="title">Drag & Drop Section</span>
          <div
            id="draggableElement"
            class="draggable"
            draggable="true"
            ondragstart="drag(event)"
          >
            Drag me!
          </div>
          <div
            id="dropZone"
            class="draggable"
            ondragover="allowDrop(event)"
            ondrop="drop(event)"
          >
            Drop here!
          </div>
        </div>

        <section>
          <h2><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Features</center></h2>

          <article>
            <h2><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Responsive Design</center></h2>
            <p><center>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Our website is designed to provide a seamless experience across
              various devices, ensuring accessibility and user satisfaction.</center>
            </p>
          </article>

          <article>
            <h2><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Advanced Technology</center></h2>
            <p><center>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;We leverage cutting-edge technologies such as HTML5, CSS3, and
              JavaScript to deliver modern and interactive features for our
              users.</center>
            </p>
          </article>
        </section>
      

              
      </section>
    </div>
  );
};

export default App;